<?php

 interface ReportExporter
{
    public function export(array $data): string;
}

class PdfExporter implements ReportExporter
{
    public function export(array $data): string
    {
        $fileName = 'hisobot.pdf';
        echo "PDF ga eksport qilindi: " . count($data['rows']) . " ta yozuv\n";
        return $fileName;
    }
}

class ExcelExporter implements ReportExporter
{
    public function export(array $data): string
    {
        $fileName = 'hisobot.xlsx';
        echo "Excel ga eksport qilindi: " . count($data['rows']) . " ta yozuv\n";
        return $fileName;
    }
}

class ReportManager
{
    private ReportExporter $exporter;
    private string $title = 'Nomsiz hisobot';

    public function __construct(ReportExporter $exporter)
    {
        $this->exporter = $exporter;
    }

    public function setTitle(string $title): void
    {
        $this->title = $title;
    }

    public function generateReport(array $data): ?string
    {
        if (empty($data)) {
            echo "Ogohlantirish: ma'lumotlar massivi bo'sh, eksport qilinmadi!\n";
            return null;
        }

        $prepared = [
            'title' => $this->title,
            'rows'  => $data,
        ];

        echo "Sarlavha: {$this->title}\n";
        return $this->exporter->export($prepared);
    }
}

$data = [
    ['id' => 1, 'name' => 'Ali',  'amount' => 1500],
    ['id' => 2, 'name' => 'Vali', 'amount' => 2300],
];

$manager = new ReportManager(new PdfExporter());
$manager->setTitle('Oylik savdo hisoboti');
echo "Fayl: " . $manager->generateReport($data) . "\n\n";

$manager = new ReportManager(new ExcelExporter());
$manager->setTitle('Yillik hisobot');
echo "Fayl: " . $manager->generateReport($data) . "\n\n";

$manager->generateReport([]);